A Pen created at CodePen.io. You can find this one at https://codepen.io/nhalstead/pen/bYxrvP.

 Click it to break it